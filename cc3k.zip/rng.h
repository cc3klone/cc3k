#ifndef _RNG_H_
#define _RNG_H_

class RNG {
    public:
        int generateInt(int end, int start = 0);
};

#endif

